package xml.parser.model;

import java.io.Serializable;

public interface Expression extends Serializable {
    double calculate();
}
