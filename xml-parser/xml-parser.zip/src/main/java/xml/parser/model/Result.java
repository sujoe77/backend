package xml.parser.model;

public class Result {
    private final double result;

    public Result(double result) {
        this.result = result;
    }
}
