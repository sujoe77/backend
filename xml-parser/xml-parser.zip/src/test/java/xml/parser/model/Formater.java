package xml.parser.model;

import org.apache.commons.io.FileUtils;
import org.junit.jupiter.api.Test;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public class Formater {
    @Test
    public void format() throws IOException {
        List<String> lines = FileUtils.readLines(new File("README.md"), StandardCharsets.UTF_8);
        List<String> lines2 = new ArrayList<>();
        for (String l : lines) {
            if (l.contains("xml.parser") && !l.contains("src/")) {
                StringBuilder sb = new StringBuilder();
                int startIndex = l.indexOf("xml.parser");
                String strBefore = l.substring(0, startIndex);
                int indexOfSpace = strBefore.length() + l.substring(startIndex).indexOf(" ");
                String strAfter = l.substring(indexOfSpace);
                String className = l.substring(startIndex, indexOfSpace);
                sb.append(strBefore)
                        .append("[")
                        .append(className)
                        .append("](src/main/java/")
                        .append(className.replace(".", "/"))
                        .append(".java")
                        .append(")");
                sb.append(strAfter);
                lines2.add(sb.toString());
            } else {
                lines2.add(l);
            }
        }
        FileUtils.writeLines(new File("README2.md"), lines2);
    }
}
